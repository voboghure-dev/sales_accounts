<div id="menuchannel">
  <h2>Settings Menu</h2>
  <ul>
    <li>
      <a class="MenuItem" href="settings">User List</a>
    </li>
    <li>
      <a class="MenuItem" href="human_resource">Employee List</a>
    </li>
  </ul>
</div>