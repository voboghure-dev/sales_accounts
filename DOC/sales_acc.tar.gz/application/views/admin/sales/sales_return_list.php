<div id="center-column">
  <div class="table">
    <img src="images/bg-th-left.gif" width="8" height="7" alt="" class="left" />
    <img src="images/bg-th-right.gif" width="7" height="7" alt="" class="right" />
    <table class="listing" cellpadding="0" cellspacing="0">
      <tr>
        <th class="full">&nbsp;</th>
      </tr>
      <tr>
        <td>
          Welcome to the Users panel! Here you can manage your user database.
        </td>
      </tr>
    </table>
  </div>
</div>