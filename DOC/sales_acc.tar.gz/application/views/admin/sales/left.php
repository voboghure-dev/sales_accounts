<div id="menuchannel">
  <h2>Sales Setup</h2>
  <ul>
    <li>
      <a class="MenuItem" href="sales_setup">Item List</a>
    </li>
    <li>
      <a class="MenuItem" href="sales_setup/supplier_list">Supplier List</a>
    </li>
    <li>
      <a class="MenuItem" href="sales_setup/customer_list">Customer List</a>
    </li>
    <li>
      <a class="MenuItem" href="sales_setup/purchase_list">Purchase List</a>
    </li>
    <li>
      <a class="MenuItem" href="sales_setup/inventory_list">Inventory List</a>
    </li>
  </ul>
</div>