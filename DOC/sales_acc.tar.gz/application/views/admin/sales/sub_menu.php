<div id="subnav">
  <ul>
    <?php if($privileges['sales_setup']==1){ ?>
    <li><a href="sales_setup">Setup</a></li>
    <li>•</li>
    <?php } ?>
    <li><a href="">Logout</a></li>
  </ul>
</div>