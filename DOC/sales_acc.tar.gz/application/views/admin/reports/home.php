<div id="site">
  <div id="content_2_column">
    <?php $this->load->view('admin/reports/sub_menu'); ?>
    
    <div id="channel_full">
      <div id="manager_header">
        <h1 id="lblPageName">Reports</h1>
      </div>

      <?php $this->load->view('admin/reports/left'); ?>

      <div id="ManagerWorkArea">
        <div style="overflow: hidden;" id="leftchannel_customer">
          
        </div>
      </div>
    </div>
  </div>
</div>