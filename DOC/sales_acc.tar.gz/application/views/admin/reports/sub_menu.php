<div id="subnav">
  <ul>
    <li><a href="">Logout</a></li>
  </ul>
</div>