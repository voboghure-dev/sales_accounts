<div id="menuchannel">
  <h2>Sales & Inventory</h2>
  <ul>
    <li><a class="MenuItem" href="reports/purchase">Purchase</a></li>
    <li><a class="MenuItem" href="reports/sales_by_date">Sales date wise</a></li>
    <li><a class="MenuItem" href="reports/sales_by_item">Sales item wise</a></li>
    <li><a class="MenuItem" href="reports/sales_by_customer">Sales customer wise</a></li>
    <li><a class="MenuItem" href="reports/transaction_all">Sales all transaction</a></li>
    <li><a class="MenuItem" href="reports/inventory_by_item">Inventory details</a></li>
  </ul>
  
  <h2>A/C Reports</h2>
  <ul class="nav">
    <li><a href="reports/account_chart_ac" class="MenuItem">Chart of A/C Details</a></li>
    <li><a href="reports/account_trial_balance" class="MenuItem">Trial Balance</a></li>
    <li><a href="reports/account_balance_sheet" class="MenuItem">Balance Sheet</a></li>
    <li><a href="reports/account_income_statement" class="MenuItem">Income Statement</a></li>
  </ul>
</div>