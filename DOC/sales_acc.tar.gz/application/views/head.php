<base href="<?php echo base_url(); ?>" />
<title><?php echo $title; ?></title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<link rel="shortcut icon" href="images/bag.ico" type="image/x-icon" />
<link type="text/css" rel="stylesheet" href="css/styles.css" />